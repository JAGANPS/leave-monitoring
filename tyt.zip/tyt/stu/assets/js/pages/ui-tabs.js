$(document).ready(function(){
    $('ul.tabs').tabs('select_tab', 'test6');
});